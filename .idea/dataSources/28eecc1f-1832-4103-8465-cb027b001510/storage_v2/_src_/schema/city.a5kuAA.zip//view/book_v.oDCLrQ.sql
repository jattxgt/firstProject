create view book_v as
  select `city`.`book`.`bid`    AS `bid`,
         `city`.`book`.`bname`  AS `bname`,
         `city`.`book`.`price`  AS `price`,
         `city`.`book`.`author` AS `author`,
         `city`.`book`.`image`  AS `image`,
         `city`.`book`.`cid`    AS `cid`
  from `city`.`book`;

